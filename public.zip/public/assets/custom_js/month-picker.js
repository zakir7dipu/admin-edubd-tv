jQuery(function($) {
    $('.month-picker').datepicker({
        autoclose: true,
        format:'yyyy-mm',
        viewMode: "months",
        minViewMode: "months",
    });
})