
jQuery(function($) {

    $('#data-table').DataTable({

        "ordering"      : false,
        "bPaginate"     : true,
        "lengthChange"  : false,
        "info"          : false,
        "pageLength"    : 25
    });
})